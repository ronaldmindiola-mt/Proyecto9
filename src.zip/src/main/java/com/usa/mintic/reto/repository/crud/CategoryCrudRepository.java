package com.usa.mintic.reto.repository.crud;

import com.usa.mintic.reto.entities.Category;
import org.springframework.data.repository.CrudRepository;

public interface CategoryCrudRepository extends CrudRepository<Category, Integer> {

}
