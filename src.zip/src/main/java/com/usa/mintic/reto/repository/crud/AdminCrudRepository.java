package com.usa.mintic.reto.repository.crud;

import com.usa.mintic.reto.entities.Admin;
import org.springframework.data.repository.CrudRepository;

public interface AdminCrudRepository extends CrudRepository<Admin, Integer> {
}
